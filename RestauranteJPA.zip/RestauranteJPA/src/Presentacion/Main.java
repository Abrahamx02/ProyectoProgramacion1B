package presentacion;

import Clases.*;
import Logica.*;
import java.util.Date;
import java.util.List;

public class Main {

    public static void main(String[] args) {

        System.out.println("-- probando sistema restaurante --");

        UsuarioJpaController usuarioCtrl = new UsuarioJpaController();
        ClienteJpaController clienteCtrl = new ClienteJpaController();
        ProductoJpaController productoCtrl = new ProductoJpaController();
        PedidoJpaController pedidoCtrl = new PedidoJpaController();
        HistorialEstadoJpaController historialCtrl = new HistorialEstadoJpaController();

        try {
            // --- administrador registra el pedido ---
            System.out.println("\n- login administrador -");
            Usuario admin = usuarioCtrl.login("cmendoza", "1234");
            System.out.println(admin.getNombre() + " | " + admin.getRol());

            System.out.println("\n- menu disponible -");
            for (Producto pr : productoCtrl.findProductoEntities()) {
                System.out.println(pr.getNombre() + " | $" + pr.getPrecio());
            }

            System.out.println("\n- registrar cliente y pedido -");
            Cliente cliente = new Cliente("Maria Garcia", "0991112233", "maria@email.com", "CLI-003");
            clienteCtrl.create(cliente);

            Pedido pedido = new Pedido("PED-003", new Date(), "Calle Nueva 100", cliente, admin);
            pedidoCtrl.create(pedido);
            System.out.println("pedido creado: " + pedido.getCodigoPedido() + " | estado: " + pedido.getEstado());

            // registrar en historial
            HistorialEstado h1 = new HistorialEstado(null, "Pendiente", new Date(), "Pedido registrado", pedido, admin);
            historialCtrl.create(h1);

            // --- cocinero toma el pedido ---
            System.out.println("\n- login cocinero -");
            Usuario cocinero = usuarioCtrl.login("pquispe", "1234");
            System.out.println(cocinero.getNombre() + " | " + cocinero.getRol());

            System.out.println("\n- pedidos pendientes -");
            for (Pedido p : pedidoCtrl.findPedidosPorEstado("Pendiente")) {
                System.out.println(p.getCodigoPedido() + " | cliente: " + p.getCliente().getNombre());
            }

            pedidoCtrl.cambiarEstado(pedido.getIdPedido(), "En preparacion");
            HistorialEstado h2 = new HistorialEstado("Pendiente", "En preparacion", new Date(), "Cocinero tomo el pedido", pedido, cocinero);
            historialCtrl.create(h2);
            System.out.println("estado actualizado: En preparacion");

            pedidoCtrl.cambiarEstado(pedido.getIdPedido(), "Listo");
            HistorialEstado h3 = new HistorialEstado("En preparacion", "Listo", new Date(), "Pedido listo para entrega", pedido, cocinero);
            historialCtrl.create(h3);
            System.out.println("estado actualizado: Listo");

            // --- repartidor entrega el pedido ---
            System.out.println("\n- login repartidor -");
            Usuario repartidor = usuarioCtrl.login("avega", "1234");
            System.out.println(repartidor.getNombre() + " | " + repartidor.getRol());

            System.out.println("\n- pedidos listos para entregar -");
            for (Pedido p : pedidoCtrl.findPedidosPorEstado("Listo")) {
                System.out.println(p.getCodigoPedido() + " | " + p.getDireccionEntrega());
            }

            pedidoCtrl.cambiarEstado(pedido.getIdPedido(), "En camino");
            HistorialEstado h4 = new HistorialEstado("Listo", "En camino", new Date(), "Repartidor salio a entregar", pedido, repartidor);
            historialCtrl.create(h4);
            System.out.println("estado actualizado: En camino");

            pedidoCtrl.cambiarEstado(pedido.getIdPedido(), "Entregado");
            HistorialEstado h5 = new HistorialEstado("En camino", "Entregado", new Date(), "Entregado a: Juan Perez", pedido, repartidor);
            historialCtrl.create(h5);
            System.out.println("estado actualizado: Entregado");

            // --- cliente consulta su pedido ---
            System.out.println("\n- consulta del cliente CLI-003 -");
            for (Pedido p : pedidoCtrl.findPedidosPorCodigoCliente("CLI-003")) {
                System.out.println("pedido: " + p.getCodigoPedido() + " | estado actual: " + p.getEstado());
            }

            // --- historial completo del pedido ---
            System.out.println("\n- historial del pedido PED-003 -");
            for (HistorialEstado h : historialCtrl.findByPedido(pedido.getIdPedido())) {
                System.out.println(h.getEstadoAnterior() + " -> " + h.getEstadoNuevo() + " | " + h.getObservacion());
            }

        } catch (Exception e) {
            System.out.println("error: " + e.getMessage());
        }

        System.out.println("\n-- fin --");
    }
}