package Clases;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "HistorialEstado")
public class HistorialEstado {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_historial")
    private Integer idHistorial;

    @Column(name = "estado_anterior")
    private String estadoAnterior;

    @Column(name = "estado_nuevo", nullable = false)
    private String estadoNuevo;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "fecha_cambio", nullable = false)
    private Date fechaCambio;

    @Column(name = "observacion")
    private String observacion;

    @ManyToOne
    @JoinColumn(name = "id_pedido", nullable = false)
    private Pedido pedido;

    // Usuario que hizo el cambio (cocinero, repartidor, etc.)
    @ManyToOne
    @JoinColumn(name = "id_usuario")
    private Usuario usuario;

    public HistorialEstado() {}

    public HistorialEstado(String estadoAnterior, String estadoNuevo, Date fechaCambio, String observacion, Pedido pedido, Usuario usuario) {
        this.estadoAnterior = estadoAnterior;
        this.estadoNuevo = estadoNuevo;
        this.fechaCambio = fechaCambio;
        this.observacion = observacion;
        this.pedido = pedido;
        this.usuario = usuario;
    }

    public Integer getIdHistorial() { return idHistorial; }
    public String getEstadoAnterior() { return estadoAnterior; }
    public void setEstadoAnterior(String e) { this.estadoAnterior = e; }
    public String getEstadoNuevo() { return estadoNuevo; }
    public void setEstadoNuevo(String e) { this.estadoNuevo = e; }
    public Date getFechaCambio() { return fechaCambio; }
    public void setFechaCambio(Date f) { this.fechaCambio = f; }
    public String getObservacion() { return observacion; }
    public void setObservacion(String o) { this.observacion = o; }
    public Pedido getPedido() { return pedido; }
    public void setPedido(Pedido pedido) { this.pedido = pedido; }
    public Usuario getUsuario() { return usuario; }
    public void setUsuario(Usuario usuario) { this.usuario = usuario; }
}