package Clases;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "Pedido")
public class Pedido {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_pedido")
    private Integer idPedido;

    @Column(name = "codigo_pedido", nullable = false, unique = true)
    private String codigoPedido;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "fecha_creacion", nullable = false)
    private Date fechaCreacion;

    @Column(name = "direccion_entrega")
    private String direccionEntrega;

    @Column(name = "total")
    private Double total;

    @Column(name = "estado")
    private String estado;

    // Quién recibe el pedido (lo registra el repartidor al entregar)
    @Column(name = "nombre_receptor")
    private String nombreReceptor;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "fecha_entrega")
    private Date fechaEntrega;

    // Cliente que hizo el pedido
    @ManyToOne
    @JoinColumn(name = "id_cliente", nullable = false)
    private Cliente cliente;

    // Usuario que registró el pedido (Administrador)
    @ManyToOne
    @JoinColumn(name = "id_usuario")
    private Usuario usuario;

    @OneToMany(mappedBy = "pedido", cascade = CascadeType.ALL)
    private List<DetallePedido> detalles;

    @OneToMany(mappedBy = "pedido", cascade = CascadeType.ALL)
    private List<HistorialEstado> historial;

    public Pedido() {}

    public Pedido(String codigoPedido, Date fechaCreacion, String direccionEntrega, Cliente cliente, Usuario usuario) {
        this.codigoPedido = codigoPedido;
        this.fechaCreacion = fechaCreacion;
        this.direccionEntrega = direccionEntrega;
        this.cliente = cliente;
        this.usuario = usuario;
        this.estado = "Pendiente";
        this.total = 0.0;
    }

    public Integer getIdPedido() { return idPedido; }
    public void setIdPedido(Integer idPedido) { this.idPedido = idPedido; }

    public String getCodigoPedido() { return codigoPedido; }
    public void setCodigoPedido(String codigoPedido) { this.codigoPedido = codigoPedido; }

    public Date getFechaCreacion() { return fechaCreacion; }
    public void setFechaCreacion(Date fechaCreacion) { this.fechaCreacion = fechaCreacion; }

    public String getDireccionEntrega() { return direccionEntrega; }
    public void setDireccionEntrega(String d) { this.direccionEntrega = d; }

    public Double getTotal() { return total; }
    public void setTotal(Double total) { this.total = total; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    public String getNombreReceptor() { return nombreReceptor; }
    public void setNombreReceptor(String nombreReceptor) { this.nombreReceptor = nombreReceptor; }

    public Date getFechaEntrega() { return fechaEntrega; }
    public void setFechaEntrega(Date fechaEntrega) { this.fechaEntrega = fechaEntrega; }

    public Cliente getCliente() { return cliente; }
    public void setCliente(Cliente cliente) { this.cliente = cliente; }

    public Usuario getUsuario() { return usuario; }
    public void setUsuario(Usuario usuario) { this.usuario = usuario; }

    public List<DetallePedido> getDetalles() { return detalles; }
    public void setDetalles(List<DetallePedido> detalles) { this.detalles = detalles; }

    @Override
    public String toString() {
        return "Pedido{codigo=" + codigoPedido + ", estado=" + estado + ", total=$" + total + "}";
    }
}