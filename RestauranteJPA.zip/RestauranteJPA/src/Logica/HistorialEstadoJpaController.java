package Logica;

import Clases.HistorialEstado;
import Logica.exceptions.PreexistingEntityException;
import javax.persistence.*;
import java.util.List;

public class HistorialEstadoJpaController {

    private EntityManagerFactory emf;

    public HistorialEstadoJpaController() {
        emf = Persistence.createEntityManagerFactory("RestauranteJPAPU");
    }

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(HistorialEstado historial) throws Exception {
        EntityManager em = getEntityManager();
        try {
            em.getTransaction().begin();
            em.persist(historial);
            em.getTransaction().commit();
        } finally {
            if (em != null) em.close();
        }
    }

    // todos los cambios de estado de un pedido especifico
    public List<HistorialEstado> findByPedido(Integer idPedido) {
        EntityManager em = getEntityManager();
        try {
            return em.createQuery(
                "SELECT h FROM HistorialEstado h WHERE h.pedido.idPedido = :id ORDER BY h.fechaCambio ASC",
                HistorialEstado.class)
                .setParameter("id", idPedido)
                .getResultList();
        } finally {
            if (em != null) em.close();
        }
    }

    public List<HistorialEstado> findHistorialEstadoEntities() {
        EntityManager em = getEntityManager();
        try {
            return em.createQuery("SELECT h FROM HistorialEstado h", HistorialEstado.class).getResultList();
        } finally {
            if (em != null) em.close();
        }
    }
}