package Logica.exceptions;

public class NonexistentEntityException extends Exception {

    private Object entity;

    public NonexistentEntityException(String message, Object entity) {
        super(message);
        this.entity = entity;
    }

    public NonexistentEntityException(String message, Object entity, Throwable cause) {
        super(message, cause);
        this.entity = entity;
    }

    public Object getEntity() {
        return entity;
    }
}