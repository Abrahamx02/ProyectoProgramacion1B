package Logica.exceptions;

public class PreexistingEntityException extends Exception {

    private Object entity;

    public PreexistingEntityException(String message, Object entity) {
        super(message);
        this.entity = entity;
    }

    public PreexistingEntityException(String message, Object entity, Throwable cause) {
        super(message, cause);
        this.entity = entity;
    }

    public Object getEntity() {
        return entity;
    }
}