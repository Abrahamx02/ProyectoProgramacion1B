package Logica;

import Clases.Pedido;
import Clases.Cliente;
import javax.persistence.*;
import java.util.Date;
import java.util.List;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import Logica.exceptions.NonexistentEntityException;
import Logica.exceptions.PreexistingEntityException;


public class PedidoJpaController {

    private EntityManagerFactory emf;

    public PedidoJpaController() {
        emf = Persistence.createEntityManagerFactory("RestauranteJPAPU");
    }

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Pedido pedido) throws PreexistingEntityException, Exception {
        EntityManager em = getEntityManager();
        try {
            em.getTransaction().begin();
            em.persist(pedido);
            em.getTransaction().commit();
        } catch (Exception ex) {
            if (findPedido(pedido.getIdPedido()) != null) {
                throw new PreexistingEntityException("El pedido " + pedido + " ya existe.", pedido, ex);
            }
            throw ex;
        } finally {
            if (em != null) em.close();
        }
    }

    public void edit(Pedido pedido) throws NonexistentEntityException, Exception {
        EntityManager em = getEntityManager();
        try {
            em.getTransaction().begin();
            em.merge(pedido);
            em.getTransaction().commit();
        } catch (Exception ex) {
            if (findPedido(pedido.getIdPedido()) == null) {
                throw new NonexistentEntityException("El pedido con id " + pedido.getIdPedido() + " no existe.", pedido);
            }
            throw ex;
        } finally {
            if (em != null) em.close();
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = getEntityManager();
        try {
            em.getTransaction().begin();
            Pedido pedido = em.getReference(Pedido.class, id);
            pedido.getIdPedido();
            em.remove(pedido);
            em.getTransaction().commit();
        } catch (EntityNotFoundException ex) {
            throw new NonexistentEntityException("El pedido con id " + id + " no existe.", ex);
        } finally {
            if (em != null) em.close();
        }
    }

    public void cambiarEstado(Integer idPedido, String nuevoEstado) throws NonexistentEntityException, Exception {
        EntityManager em = getEntityManager();
        try {
            em.getTransaction().begin();
            Pedido pedido = em.find(Pedido.class, idPedido);
            if (pedido == null) {
                throw new NonexistentEntityException("El pedido con id " + idPedido + " no existe.", idPedido);
            }
            pedido.setEstado(nuevoEstado);
            em.merge(pedido);
            em.getTransaction().commit();
        } finally {
            if (em != null) em.close();
        }
    }

    public List<Pedido> findPedidoEntities() {
        return findPedidoEntities(true, -1, -1);
    }

    public List<Pedido> findPedidoEntities(int maxResults, int firstResult) {
        return findPedidoEntities(false, maxResults, firstResult);
    }

    private List<Pedido> findPedidoEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Pedido.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            if (em != null) em.close();
        }
    }

    public Pedido findPedido(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Pedido.class, id);
        } finally {
            if (em != null) em.close();
        }
    }

    public int getPedidoCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Pedido> rt = cq.from(Pedido.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            if (em != null) em.close();
        }
    }
    public List<Pedido> findPedidosPorCodigoCliente(String codigoAcceso) {
    EntityManager em = getEntityManager();
    try {
        return em.createQuery(
            "SELECT p FROM Pedido p WHERE p.cliente.codigoAcceso = :codigo", Pedido.class)
            .setParameter("codigo", codigoAcceso)
            .getResultList();
    } finally {
        if (em != null) em.close();
    }
}

public List<Pedido> findPedidosPorEstado(String estado) {
    EntityManager em = getEntityManager();
    try {
        return em.createQuery(
            "SELECT p FROM Pedido p WHERE p.estado = :estado", Pedido.class)
            .setParameter("estado", estado)
            .getResultList();
    } finally {
        if (em != null) em.close();
    }
}
}