package Logica;
import Clases.Usuario;
import Logica.exceptions.NonexistentEntityException;
import Logica.exceptions.PreexistingEntityException;
import javax.persistence.*;
import javax.persistence.criteria.CriteriaQuery;
import java.util.List;

public class UsuarioJpaController {

    private EntityManagerFactory emf;

    public UsuarioJpaController() {
        emf = Persistence.createEntityManagerFactory("RestauranteJPAPU");
    }

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Usuario usuario) throws PreexistingEntityException, Exception {
        EntityManager em = getEntityManager();
        try {
            em.getTransaction().begin();
            em.persist(usuario);
            em.getTransaction().commit();
        } catch (Exception ex) {
            if (findUsuario(usuario.getIdUsuario()) != null) {
                throw new PreexistingEntityException("El usuario " + usuario + " ya existe.", usuario, ex);
            }
            throw ex;
        } finally {
            if (em != null) em.close();
        }
    }

    public void edit(Usuario usuario) throws NonexistentEntityException, Exception {
        EntityManager em = getEntityManager();
        try {
            em.getTransaction().begin();
            em.merge(usuario);
            em.getTransaction().commit();
        } catch (Exception ex) {
            if (findUsuario(usuario.getIdUsuario()) == null) {
                throw new NonexistentEntityException("El usuario con id " + usuario.getIdUsuario() + " no existe.", usuario);
            }
            throw ex;
        } finally {
            if (em != null) em.close();
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = getEntityManager();
        try {
            em.getTransaction().begin();
            Usuario usuario = em.getReference(Usuario.class, id);
            usuario.getIdUsuario();
            em.remove(usuario);
            em.getTransaction().commit();
        } catch (EntityNotFoundException ex) {
            throw new NonexistentEntityException("El usuario con id " + id + " no existe.", ex);
        } finally {
            if (em != null) em.close();
        }
    }

    // Buscar usuario por username y password (para simular login)
    public Usuario login(String username, String password) {
        EntityManager em = getEntityManager();
        try {
            return (Usuario) em.createQuery(
                "SELECT u FROM Usuario u WHERE u.username = :username AND u.password = :password")
                .setParameter("username", username)
                .setParameter("password", password)
                .getSingleResult();
        } catch (NoResultException e) {
            return null;
        } finally {
            if (em != null) em.close();
        }
    }

    public List<Usuario> findUsuarioEntities() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Usuario.class));
            return em.createQuery(cq).getResultList();
        } finally {
            if (em != null) em.close();
        }
    }

    public Usuario findUsuario(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Usuario.class, id);
        } finally {
            if (em != null) em.close();
        }
    }
}